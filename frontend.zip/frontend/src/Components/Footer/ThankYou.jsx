import React from 'react';
import './ThankYou.css';

const ThankYou = () => {
  return (
    <div className="thank-you">
      <header className="thank-you-header">
        <h1>Thank You!</h1>
      </header>
      <section className="thank-you-content">
        <p>We have received your message and will get back to you shortly.</p>
        <p>In the meantime, feel free to browse our <a href="/products">products</a> or learn more <a href="/about-us">about us</a>.</p>
      </section>
    </div>
  );
};

export default ThankYou;
