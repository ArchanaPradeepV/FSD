import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  return (
    <div className="about-us">
      <header className="about-us-header">
        <h1>About Us</h1>
      </header>
      <section className="about-us-content">
        <p>Welcome to EBELE. We are dedicated to creating stylish, high-quality clothing that respects our planet.</p>
        
        <h2>Our Mission</h2>
        <p>At EBELE, our mission is to inspire a conscious and fashionable lifestyle through sustainable practices and ethical labor standards, making a positive impact on the environment and the communities we touch.</p>
        
        <h2>Our Team</h2>
      
        <div className="team-member">
          <h5>ARCHANA PRADEEP</h5>
        </div>
        <div className="team-member">
          <h5>HUDHA FATHIMA</h5>
        </div>
        <div className="team-member">
          <h5>ROHITH</h5>
        </div>

        
      </section>
    </div>
  );
};

export default AboutUs;
